package activity2;

/**
 * This is a class that tests the activity2.Deck class.
 */
public class DeckTester {

	/**
	 * The main method in this class checks the activity2.Deck operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {
		/* *** TO BE IMPLEMENTED IN ACTIVITY 2 *** */
	}
}
