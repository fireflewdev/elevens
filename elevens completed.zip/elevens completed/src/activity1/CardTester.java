package activity1;
/**
 * This is a class that tests the activity2.Card class.
 */
public class CardTester {

	/**
	 * The main method in this class checks the activity2.Card operations for consistency.
	 *	@param args is not used.
	 */
	public static void main(String[] args) {

	}
}
